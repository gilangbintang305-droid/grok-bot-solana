package com.grokbotsolana

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        root.addView(TextView(this).apply {
            text = "GROK BOT SOLANA"
            textSize = 25f
            setTextColor(Color.rgb(20, 35, 60))
            gravity = Gravity.CENTER
        })
        val status = TextView(this).apply {
            text = "\nStatus: Mode simulasi / wallet belum terhubung.\n\nTrading otomatis belum diaktifkan."
            textSize = 16f
            setTextColor(Color.DKGRAY)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Jalankan simulasi"
            setOnClickListener {
                status.text = "Status: Simulasi berjalan.\nTidak ada transaksi nyata atau dana yang digunakan."
            }
        })
        root.addView(TextView(this).apply {
            text = "\nKeamanan: jangan pernah memasukkan seed phrase atau private key ke aplikasi atau GitHub. Uji di Devnet sebelum transaksi nyata."
            textSize = 13f
            setTextColor(Color.GRAY)
        })
        setContentView(root)
    }
}
