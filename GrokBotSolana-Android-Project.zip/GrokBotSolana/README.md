# GROK BOT SOLANA — Android Studio project

Status: **UI prototype only (paper/demo mode)**. This source project is not a live trading bot and does not yet sign or submit swaps.

## Build an APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select Build → Build Bundle(s) / APK(s) → Build APK(s).
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important safety boundary
- No seed phrase, private key, or exchange secret is requested or stored.
- The dashboard uses illustrative demo figures and local browser state only.
- Auto Buy / Auto Sell controls are intentionally demo-only and do not submit transactions.
- Never paste a seed phrase or private key into this app.

## Planned production integration
Use Jupiter Swap API V2 (`GET /swap/v2/order` then wallet-sign, then `POST /swap/v2/execute`) and Solana Mobile Wallet Adapter (MWA) for external wallet signing. Jupiter API V2 requires an `x-api-key` for production use. Keep any service API key on a backend, not in the APK. Before enabling live orders, implement transaction preview, wallet confirmation for every swap, token-risk checks, spend caps, slippage caps, daily loss limits, and an emergency stop.

References:
- https://developers.jup.ag/docs/swap
- https://github.com/solana-mobile/mobile-wallet-adapter
